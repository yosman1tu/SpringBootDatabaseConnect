package com.coder;

import org.apache.ibatis.type.MappedTypes;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.context.annotation.ComponentScan;

import com.coder.model.Users;

@MappedTypes(Users.class)
@MapperScan("com.coder.mapper")
@SpringBootApplication
public class Mysql2Application {

	public static void main(String[] args) {
		SpringApplication.run(Mysql2Application.class, args);
	}
}
